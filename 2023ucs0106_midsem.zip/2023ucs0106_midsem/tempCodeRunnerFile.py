
# print(f"parent1: {path1} \nparent2: {path2}")
# print(f"child1:{childs[0]} \nchild2: {childs[1]}")